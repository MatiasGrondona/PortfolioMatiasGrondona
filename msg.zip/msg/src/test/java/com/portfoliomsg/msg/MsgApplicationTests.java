package com.portfoliomsg.msg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsgApplicationTests {

	@Test
	void contextLoads() {
	}

}
